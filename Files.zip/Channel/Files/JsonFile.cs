﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Tdc.LarsCSharpWorkShop.Api.Common;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Tdc.LarsCSharpWorkShop.Channel.Files
{
    public class JsonFile
    {
        public string DataFile { get; set; }
        public List<PersonJson> List { get; set; } = new();

        public JsonFile(string dataFile)
        {
            DataFile = dataFile;
            if (!File.Exists(DataFile))
            {
                throw new Exception("File was not found");
            }
        }

        public void Display()
        {
            foreach (var item in List)
            {
                Console.WriteLine(item.Display);
            }
        }
        public void Read()
        {
            using (var sr = new StreamReader(DataFile))
            {
                string data = sr.ReadToEnd();
                List = SerializationJson.Deserialize<List<PersonJson>>(data);
            }
        }

        public void Write()
        {
            string data = Api.Common.SerializationJson.Serialize(List);
            using (var sw = new StreamWriter(DataFile))
            {
                sw.WriteLine(data);
            }
        }
    }
}