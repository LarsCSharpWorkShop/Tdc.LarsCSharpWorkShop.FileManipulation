﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection.PortableExecutable;
using System.Text;
using Tdc.LarsCSharpWorkShop.Api.Common;

namespace Tdc.LarsCSharpWorkShop.Channel.Files
{
    public class OffsetFile
    {
        public string DataFile { get; set; }
        public List<PersonOffset> List { get; set; } = new();

        const int SIZE_OF_HEADER = 18;
        const int NUMBER_SIZE = 10;
        const int SIZE_OF_FOOTER = 6;

        public OffsetFile(string dataFile)
        {
            DataFile = dataFile;
            if (!File.Exists(DataFile))
            {
                throw new Exception("File was not found");
            }
        }

        public void Display()
        {
            foreach (var item in List)
            {
                Console.WriteLine(item.Display);
            }
        }
        private string ReadHeader(FileStream fs, ref int pos)
        {
            byte[] buffer = new byte[SIZE_OF_HEADER];

            // seeks from the beginning of file              
            fs.Seek(0, SeekOrigin.Begin);

            int amtRead = fs.Read(buffer, 0, SIZE_OF_HEADER);
            pos += amtRead;
            if (amtRead == SIZE_OF_HEADER)
            {
                return Encoding.UTF8.GetString(buffer);
            }
            return string.Empty;
        }

        public void Read(int startRecord, int amountToRead)
        {
            byte[] buffer;
            int pos = 0;
            int count = 0;
            int amountOfRecordsRead = 0;
            int amtRead;

            using (var fs = new FileStream(DataFile, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                string header = ReadHeader(fs, ref pos);
                if (!string.IsNullOrWhiteSpace(header))
                {
                    try
                    {
                        count = Convert.ToInt32(header.Replace("*", "")
                                                      .Replace("START", "")
                                                      .Replace("#", ""));

                        if (amountToRead < count)
                        {
                            count = amountToRead;
                        }

                        // seeks from where the cursor is currently at
                        fs.Seek(startRecord * PersonOffset.FileRecordSize, SeekOrigin.Current);
                        pos += startRecord * PersonOffset.FileRecordSize;
                        while (amountOfRecordsRead < count)
                        {
                            buffer = new byte[PersonOffset.FileRecordSize];
                            amtRead = fs.Read(buffer, 0, PersonOffset.FileRecordSize);
                            pos += amtRead;
                            if (amtRead == PersonOffset.FileRecordSize)
                            {
                                PersonOffset personOffset = new(Encoding.UTF8.GetString(buffer));
                                List.Add(personOffset);
                                amountOfRecordsRead++;
                            }
                            else
                            {
                                // error code
                                break;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }

        private void WriteHeader(FileStream fs)
        {
            byte[] buffer = new byte[SIZE_OF_HEADER];
            fs.Seek(0, SeekOrigin.Begin);
            string s = $"***START{List.Count.ToString().PadLeft(NUMBER_SIZE, '#')}";
            buffer = new UTF8Encoding(true).GetBytes(s);
            fs.Write(buffer);
        }
        private void WriteFooter(FileStream fs)
        {
            byte[] buffer = new byte[SIZE_OF_FOOTER];                        
            string s = $"***END";
            buffer = new UTF8Encoding(true).GetBytes(s);
            fs.Write(buffer);
        }        

        public void Write()
        {
            byte[] buffer;
            using (var fs = new FileStream(DataFile, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                WriteHeader(fs);
                foreach (var item in List)
                {
                    buffer = new UTF8Encoding(true).GetBytes(item.FileRecord);
                    fs.Write(buffer);
                }
                WriteFooter(fs);
            }
        }
    }
}
