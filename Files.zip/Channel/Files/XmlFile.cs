﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Tdc.LarsCSharpWorkShop.Api.Common;

namespace Tdc.LarsCSharpWorkShop.Channel.Files
{
    public class XmlFile
    {
        public string DataFile { get; set; }
        public List<PersonXml> List { get; set; } = new();

        public XmlFile(string dataFile)
        {
            DataFile = dataFile;
            if (!File.Exists(DataFile))
            {
                throw new Exception("File was not found");
            }
        }

        public void Display()
        {
            foreach (var item in List)
            {
                Console.WriteLine(item.Display);
            }
        }
        public void Read()
        {
            using (var sr = new StreamReader(DataFile))
            {
                string data = sr.ReadToEnd();
                List = SerializationXml.Deserialize<List<PersonXml>>(data);
            }
        }

        public void Write()
        {
            string data = Api.Common.SerializationXml.Serialize(List);
            using (var sw = new StreamWriter(DataFile))
            {
                sw.WriteLine(data);
            }
        }
    }
}
