﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Tdc.LarsCSharpWorkShop.Api.Common;

namespace Tdc.LarsCSharpWorkShop.Channel.Files
{
    public class CsvFile
    {
        public string DataFile { get; set; }
        public List<PersonCsv> List { get; set; } = new();

        public CsvFile(string dataFile)
        {
            DataFile = dataFile;
            if (!File.Exists(DataFile))
            {
                throw new Exception("File was not found");
            }
        }

        public void Display()
        {
            foreach (var item in List)
            {
                Console.WriteLine(item.Display);
            }
        }
        public void Read()
        {
            using (var sr = new StreamReader(DataFile))
            {
                List<string> lines = sr.ReadToEnd().Split("\r\n").ToList();
                lines = lines.Where(x => !string.IsNullOrWhiteSpace(x)).Skip(1).ToList();
                foreach (var line in lines)
                {
                    List<string> parts = line.Split(',').ToList();
                    PersonCsv personCsv = new()
                    {
                        FirstName = parts[0].Trim(),
                        LastName = parts[1].Trim()
                    };
                    List.Add(personCsv);
                }
            }
        }

        public void Write()
        {
            using (var sw = new StreamWriter(DataFile))
            {
                sw.WriteLine($"FirstName,LastName");
                foreach (var item in List)
                {
                    sw.WriteLine($"{item.FirstName},{item.LastName}");
                }
            }
        }
    }
}
