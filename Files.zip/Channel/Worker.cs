﻿using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Tdc.LarsCSharpWorkShop.Api.Common;
using Tdc.LarsCSharpWorkShop.Api.Configuration;
using Tdc.LarsCSharpWorkShop.Channel.Files;

namespace Tdc.LarsCSharpWorkShop.Channel
{
    /* File Methods
     * Used Most 
     * ----------
     * Exists
     * Open
     * Create
     * Delete 
     * Copy
     * Move
     * Replace
     * ReadLines
     * ReadAllLines
     * AppendText
     * AppendAllText
     * AppendAllLines
     * WriteAllLines
     *   
     *   
     * Used Less
     * ---------
     * OpenRead
     * OpenWrite 
     * SetAttributes
     * SetCreationTime
     * SetCreationTimeUtc
     * SetLastAccessTime
     * SetLastAccessTimeUtc
     * SetLastWriteTime
     * SetLastWriteTimeUtc
     * GetAttributes
     * GetCreationTime
     * GetCreationTimeUtc
     * GetLastAccessTime
     * GetLastAccessTimeUtc
     * GetLastWriteTime
     * GetLastWriteTimeUtc
     *   
     *   
     * Used Least
     * ----------
     * AppendAllBytes
     * CreateSymbolicLink
     * CreateText
     * Decrypt
     * Encrypt 
     * OpenHandle
     * OpenText
     * ReadAllBytes 
     * ReadAllText
     * WriteAllText 
     * ResolveLinkTarget
     * SetUnixFileMode
     * WriteAllBytes 
     * GetUnixFileMode
     * 
     * 
     * Same as above but for Async
     * ---------------------------
     * AppendAllBytesAsync
     * AppendAllLinesAsync
     * AppendAllTextAsync
     * ReadAllBytesAsync 
     * ReadAllLinesAsync
     * ReadAllTextAsync
     * ReadLinesAsync
     * WriteAllBytesAsync 
     * WriteAllLinesAsync 
     * WriteAllTextAsync
     */

    /*
       FileInfo 
       DirectoryInfo
       DriveInfo   
    */

    public class Worker : BackgroundService
    {
        private readonly IHostApplicationLifetime iHostApplicationLifetime;
        private readonly string DataPath;

        private CsvFile csvFile;
        private XmlFile xmlFile;
        private JsonFile jsonFile;
        private OffsetFile offsetFile;

        public Worker(IHostApplicationLifetime iHostApplicationLifetime, IFolderConfig iFolderConfig)
        {
            this.iHostApplicationLifetime = iHostApplicationLifetime;
            DataPath = iFolderConfig.FolderConfigSettings.FirstOrDefault(x => x.Name == "Data")?.Path;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                //offsetFile = await Offset();
                //csvFile = await Csv();
                //xmlFile = await Xml();
                jsonFile = await Json();

            }
            catch
            {
                throw;
            }
            finally
            {
                this.iHostApplicationLifetime.StopApplication();
            }
        }

        public async Task<CsvFile> Csv()
        {
            var data = new CsvFile($"{DataPath}\\data.csv");

            data.Read();
            data.Display();
            //data.List[0].FirstName = "Lawrence";
            data.Write();
            return data;
        }
        public async Task<XmlFile> Xml()
        {
            var data = new XmlFile($"{DataPath}\\data.xml");

            data.Read();
            data.Display();
           // data.List[0].FirstName = "Lawrence";
            data.Write();
            return data;
        }
        public async Task<JsonFile> Json()
        {
            var data = new JsonFile($"{DataPath}\\data.json");

            data.Read();
            data.Display();
            //data.List[0].FirstName = "Lawrence";
            data.Write();

            return data;
        }
        public async Task<OffsetFile> Offset()
        {
            var data = new OffsetFile($"{DataPath}\\data.txt");
           
            data.Read(2, 2);
            data.Display();
            //data.List[0].FirstName = "Lawrence";
           // data.Write();

            return data;
        }
    }
}
