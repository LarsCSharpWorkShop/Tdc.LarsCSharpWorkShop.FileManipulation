﻿using Microsoft.Extensions.Configuration;
using System;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Tdc.LarsCSharpWorkShop.Api.Configuration.Builders;
using Tdc.LarsCSharpWorkShop.Channel;

// Add Connector code to the container
IConfiguration configuration = Channel.ReadAppSettings(AppDomain.CurrentDomain.BaseDirectory);

// Add services to the container.
HostApplicationBuilder builder = Host.CreateApplicationBuilder(args);
builder.Services.AddHostedService<Worker>();
Channel.AddServices(builder.Services, configuration);

using IHost host = builder.Build();
host.Run();