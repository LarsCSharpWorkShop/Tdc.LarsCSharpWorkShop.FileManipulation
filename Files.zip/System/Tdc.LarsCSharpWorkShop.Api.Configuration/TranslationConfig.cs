﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;

namespace Tdc.LarsCSharpWorkShop.Api.Configuration
{
    public interface ITranslationConfig
    {
        string RootFolder { get; set; }
        List<TranslationConfigSetting> TranslationConfigSettings { get; set; }
    }
    public class TranslationConfig : ITranslationConfig
    {
        public string RootFolder { get; set; }
        public List<TranslationConfigSetting> TranslationConfigSettings { get; set; }

        public static TranslationConfig Load(IConfiguration config)
        {
            TranslationConfig result = null;
            try
            {
                IConfigurationSection section = config.GetSection("TranslationConfig");
                // section.Get requires Microsoft.Extensions.Hosting
                result = section?.Get<TranslationConfig>();
            }
            catch (Exception ex)
            {
            }
            return result;
        }
    }
    public class TranslationConfigSetting
    {
        public string Name { get; set; }
        public string Path { get; set; }
    }
}
