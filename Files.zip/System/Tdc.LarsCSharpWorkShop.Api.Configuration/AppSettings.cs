using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using System;

namespace Tdc.LarsCSharpWorkShop.Api.Configuration
{
    public class AppSettings
    {
        public static IConfiguration Read(string baseDirectory, string fileName = "appsettings.json")
        {
            return new ConfigurationBuilder()
                         .SetBasePath(baseDirectory)
                         .AddJsonFile(fileName).Build();
        }

        public static IServiceCollection AddServices(IServiceCollection services, IConfiguration configuration, bool addAuthentication = false)
        {
            services.AddSingleton<IApplicationSpecificsConfig, ApplicationSpecificsConfig>(p => ApplicationSpecificsConfig.Load(configuration));
    ;

            if (addAuthentication)
            {
                try
                {
                    IServiceProvider serviceProvider = services.BuildServiceProvider();

                    IJwtBearerConfig iJwtBearerConfig = serviceProvider.GetRequiredService<IJwtBearerConfig>();
                    if (iJwtBearerConfig != null)
                    {
                        services
                            .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                            .AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, options =>
                            {
                                options.Authority = iJwtBearerConfig.Authority;
                                options.Audience = iJwtBearerConfig.Audience;
                                options.TokenValidationParameters = new TokenValidationParameters
                                {
                                    NameClaimType = "https://infolink.crown/userId",
                                };
                            });
                    }
                }
                catch (Exception ex)
                {
                    // do nothing
                }
            }
            return services;
        }

    }
}
