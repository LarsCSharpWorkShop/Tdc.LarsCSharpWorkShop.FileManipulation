using Microsoft.Extensions.Configuration;
using System;

namespace Tdc.LarsCSharpWorkShop.Api.Configuration
{
    public interface IGitHubConfig : IConfig
    {
        public string AuthorList { get; set; }
        public string PAT { get; set; }
    }
    public class GitHubConfig : IGitHubConfig
    {
        public string AuthorList { get; set; }
        public string PAT { get; set; }
        public static GitHubConfig Load(IConfiguration config)
        {
            GitHubConfig result = null;
            try
            {
                IConfigurationSection section = config.GetSection("GitHubConfig");
                // section.Get requires Microsoft.Extensions.Hosting
                result = section?.Get<GitHubConfig>();
            }
            catch (Exception ex)
            {
            }
            return result;
        }

        public override string ToString()
        {
            return $"{PAT}";
        }
    }
}
