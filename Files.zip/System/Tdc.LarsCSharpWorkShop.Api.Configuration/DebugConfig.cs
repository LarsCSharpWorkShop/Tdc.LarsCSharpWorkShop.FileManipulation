using Microsoft.Extensions.Configuration;
using System;

namespace Tdc.LarsCSharpWorkShop.Api.Configuration
{
    public interface IDebugConfig : IConfig
    {
        public bool Enabled { get; set; }
    }
    public class DebugConfig  :IDebugConfig
    {
        public bool Enabled { get; set; }
        public static DebugConfig Load(IConfiguration config)
        {
            DebugConfig result = null;
            try
            {
                IConfigurationSection section = config.GetSection("DebugConfig");
                // section.Get requires Microsoft.Extensions.Hosting
                result = section?.Get<DebugConfig>();
            }
            catch (Exception ex)
            {
            }
            return result;
        }
    }
}
