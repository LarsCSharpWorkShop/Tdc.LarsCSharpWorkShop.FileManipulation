using Microsoft.Extensions.Configuration;
using System.Collections.Generic;

namespace Tdc.LarsCSharpWorkShop.Api.Configuration
{
    public interface IApplicationSpecificsConfig : IConfig
    {
        public List<DatabaseName> Databases { get; set; }
        public string Database { get; set; }
        public int Run { get; set; }
        public List<GlobalColumn> GlobalColumns { get; set; }
        public string Company { get; set; }
        public string Application { get; set; }
        public string CompanyAndApplication { get; }
        public string ListOrderFile { get; set; }
        public string OutputDirectory { get; set; }
        public string DataDirectory { get; set; }
        public string DataBaseType { get; set; }
        public string DataBaseName { get; set; }
        public string DbDatabaseName { get; set; }
        public string RepositoryUrl { get; set; }
        public bool UsePackageReference { get; set; }
    }
    public class ApplicationSpecificsConfig : IApplicationSpecificsConfig
    {
        public List<DatabaseName> Databases { get; set; }
        public string Database { get; set; }
        public int Run { get; set; }
        public List<GlobalColumn> GlobalColumns { get; set; }
        public string Company { get; set; }
        public string Application { get; set; }
        public string CompanyAndApplication => $"{Company}.{Application}";
        public string ListOrderFile { get; set; }
        public string OutputDirectory { get; set; }
        public string DataDirectory { get; set; }
        public string DataBaseType { get; set; }
        public string DataBaseName { get; set; }
        public string DbDatabaseName { get; set; }
        public string RepositoryUrl { get; set; }
        public bool UsePackageReference { get; set; } = true;
        public static ApplicationSpecificsConfig Load(IConfiguration config)
        {
            IConfigurationSection section = config.GetSection("ApplicationSpecificsConfig");
            // section.Get requires Microsoft.Extensions.Hosting
            return section.Get<ApplicationSpecificsConfig>();
        }
    }

    public class GlobalColumn
    {
        public string Name { get; set; }
    }
    public class DatabaseName
    {
        public string Name { get; set; }
    }
}
