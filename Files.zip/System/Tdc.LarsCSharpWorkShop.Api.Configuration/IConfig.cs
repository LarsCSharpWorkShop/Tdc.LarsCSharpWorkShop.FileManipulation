namespace Tdc.LarsCSharpWorkShop.Api.Configuration
{
    public interface IConfig
    {
      //  IConfig Load(IConfiguration config);
    }
}
