using Microsoft.Extensions.Configuration;
using System;

namespace Tdc.LarsCSharpWorkShop.Api.Configuration
{
    public interface IJwtBearerConfig : IConfig
    {
         public string Authority  {get;set;}
         public string Audience {get;set;}
    }
    public class JwtBearerConfig : IJwtBearerConfig
    {
        public string Authority { get; set; }
        public string Audience { get; set; }

        public static JwtBearerConfig Load(IConfiguration config)
        {
            JwtBearerConfig result = null;
            try
            {
                IConfigurationSection section = config.GetSection("JwtBearerConfig");
                // section.|et requires Microsoft.Extensions.Hosting
                result = section?.Get<JwtBearerConfig>();
            }
            catch (Exception ex)
            {              
            }
            return result;
        }
    }
}
