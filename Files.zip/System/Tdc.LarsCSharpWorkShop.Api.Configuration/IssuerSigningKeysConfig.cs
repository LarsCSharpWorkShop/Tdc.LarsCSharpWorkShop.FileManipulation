﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Text;

namespace Tdc.LarsCSharpWorkShop.Api.Configuration
{
    public interface IissuerSigningKeysConfig : IConfig
    {
        public List<IssuerSigningKey> IssuerSigningKeys { get; set; }
    }

    public class IssuerSigningKeysConfig : IissuerSigningKeysConfig
    {
        public List<IssuerSigningKey> IssuerSigningKeys { get; set; }
        public static IssuerSigningKeysConfig Load(IConfiguration config)
        {
            IssuerSigningKeysConfig result = null;
            try
            {
                IConfigurationSection section = config.GetSection("IssuerSigningKeysConfig");
                // section.Get requires Microsoft.Extensions.Hosting
                result = section.Get<IssuerSigningKeysConfig>();
            }
            catch (Exception ex)
            {
            }
            return result;

        }
    }

    public class IssuerSigningKey
    {
     
        public string alg { get; set; }
        public string kty { get; set; }
        public string use { get; set; }
        public string n { get; set; }
        public string e { get; set; }
        public string kid { get; set; }
        public string x5t { get; set; }
        public List<string> x5c { get; set; }

        public SymmetricSecurityKey SymmetricSecurityKey => new SymmetricSecurityKey(Encoding.ASCII.GetBytes($"{n}{e}")); 
    }
}
