﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;

namespace Tdc.LarsCSharpWorkShop.Api.Configuration
{
    public interface IKeyValuePairConfig
    {
        List<KeyValuePairConfigSetting> KeyValuePairConfigSettings { get; set; }
    }
    public class KeyValuePairConfig : IKeyValuePairConfig
    {
        public List<KeyValuePairConfigSetting> KeyValuePairConfigSettings { get; set; }

        public static KeyValuePairConfig Load(IConfiguration config)
        {
            KeyValuePairConfig result = null;
            try
            {
                IConfigurationSection section = config.GetSection("KeyValuePairConfig");
                // section.Get requires Microsoft.Extensions.Hosting
                result = section?.Get<KeyValuePairConfig>();
            }
            catch (Exception ex)
            {
            }
            return result;
        }
    }
    public class KeyValuePairConfigSetting
    {
        public string Name { get; set; }
        public string Key { get; set; }
        public string Value { get; set; }
    }
}
