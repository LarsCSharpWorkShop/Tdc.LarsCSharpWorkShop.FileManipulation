﻿namespace Tdc.LarsCSharpWorkShop.Api.Configuration.Builders
{
    public class Channel : BaseBuilder
    {
    }
}
