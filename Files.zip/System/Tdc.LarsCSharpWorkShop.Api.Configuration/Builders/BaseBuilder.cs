﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using System;

namespace Tdc.LarsCSharpWorkShop.Api.Configuration.Builders
{
    public class BaseBuilder
    {
        public static IConfiguration ReadAppSettings(string baseDirectory, string fileName = "appsettings.json")
        {
            return new ConfigurationBuilder()
                         .SetBasePath(baseDirectory)
                         .AddJsonFile(fileName, false, true).Build();
        }

        public static IServiceCollection AddServices(IServiceCollection services, IConfiguration configuration, bool addAuthentication = false)
        {
            services.AddSingleton<IHttpClientConfig, HttpClientConfig>(p => HttpClientConfig.Load(configuration))
                    .AddSingleton<IDebugConfig, DebugConfig>(p => DebugConfig.Load(configuration))
                    .AddSingleton<ISecurityConfig, SecurityConfig>(p => SecurityConfig.Load(configuration))
                    .AddSingleton<IGitHubConfig, GitHubConfig>(p => GitHubConfig.Load(configuration))
                    .AddSingleton<IFolderConfig, FolderConfig>(p => FolderConfig.Load(configuration))
                    .AddSingleton<IRepositoryConfig, RepositoryConfig>(p => RepositoryConfig.Load(configuration))
                    .AddSingleton<IJwtBearerConfig, JwtBearerConfig>(p => JwtBearerConfig.Load(configuration));

            if (addAuthentication)
            {
                try
                {
                    IServiceProvider serviceProvider = services.BuildServiceProvider();

                    IJwtBearerConfig iJwtBearerConfig = serviceProvider.GetRequiredService<IJwtBearerConfig>();
                    if (iJwtBearerConfig != null)
                    {
                        string secretKey = "this needs to be at least 32 chars long!";

                        services
                            .AddAuthentication(options =>
                            {
                                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
                                options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
                            })
                            .AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, options =>
                            {
                                options.SaveToken = true;
                                options.RequireHttpsMetadata = false;
                                options.TokenValidationParameters = new TokenValidationParameters
                                {
                                    ValidateIssuer = true,
                                    ValidateAudience = true,
                                    ValidAudience = iJwtBearerConfig.Audience,
                                    ValidIssuer = iJwtBearerConfig.Authority,
                                    IssuerSigningKey = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes(secretKey)),
                                    NameClaimType = $"CustomerId",
                                };
                            });
                    }
                }
                catch (Exception ex)
                {
                    // do nothing
                }
            }
            return services;
        }

    }
}
