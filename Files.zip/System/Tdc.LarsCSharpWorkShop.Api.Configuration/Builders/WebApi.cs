using Asp.Versioning;
using Microsoft.Extensions.DependencyInjection;

namespace Tdc.LarsCSharpWorkShop.Api.Configuration.Builders
{
    public class WebApi : BaseBuilder
    {
        public static IServiceCollection AddControllerInformation(IServiceCollection services)
        {
            services.AddControllers();
            services.AddApiVersioning(options =>
            {
                options.DefaultApiVersion = new ApiVersion(1, 0);
                options.AssumeDefaultVersionWhenUnspecified = true;
                options.ReportApiVersions = true;
            })
            .AddApiExplorer(options =>
            {
                options.GroupNameFormat = "'v'VVV";
                options.SubstituteApiVersionInUrl = true;
            });

            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            services.AddEndpointsApiExplorer();
            services.AddOpenApi();

            return services;
        }
    }
}
