namespace Tdc.LarsCSharpWorkShop.Api.Configuration
{
    internal class EmailConfig
    {
    }
}
