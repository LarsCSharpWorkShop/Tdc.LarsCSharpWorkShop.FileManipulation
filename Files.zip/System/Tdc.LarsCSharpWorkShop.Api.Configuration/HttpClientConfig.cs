using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Tdc.LarsCSharpWorkShop.Api.Configuration
{
    public interface IHttpClientConfig : IConfig
    {
        public List<HttpClientSetting> HttpClientSettings { get; set; }
    }
    public class HttpClientConfig : IHttpClientConfig
    {
        public List<HttpClientSetting> HttpClientSettings { get; set; }

        public static HttpClientConfig Load(IConfiguration config)
        {
            HttpClientConfig result = null;
            try
            {
                IConfigurationSection section = config.GetSection("HttpClientConfig");
                // section.Get requires Microsoft.Extensions.Hosting
                result = section?.Get<HttpClientConfig>();
            }
            catch (Exception ex)
            {
            }
            return result;
        }
    }
    public class HttpClientSetting
    {
        public bool UseHttps { get; set; } = true;
        public string BaseUrl { get; set; } = "localhost";
        public string Service { get; set; }
        public string Grouping { get; set; }
        public string Controller { get; set; }
        // public string Url { get; set; }
        public string Url => Service + Grouping + Controller;
        public string HttpPort { get; set; }
        public string HttpsPort { get; set; }
        public string Version { get; set; }
        public string Timeout { get; set; } = "0, 2, 0"; // format hh,mm,ss

        public TimeSpan GetTimeout()
        {
            //TimeSpan result = new(0, 2, 0);
            //if (!string.IsNullOrEmpty(Timeout))
            //{
            List<string> parts = Timeout.Split(",").ToList();
            if (parts.Count == 3)
            {
                return new TimeSpan(Convert.ToInt32(parts[0]), Convert.ToInt32(parts[1]), Convert.ToInt32(parts[2]));
            }
            return new(0, 2, 0);
            //}
            //return result;
        }
    }
}
