﻿using Microsoft.Extensions.Configuration;
using System;

namespace Tdc.LarsCSharpWorkShop.Api.Configuration
{
    public interface IUserSettingConfig : IConfig
    {
        public string TableNameUserPreference { get; set; }
        public string TableNameGlobalPreference { get; set; }
        public string TableNameCustomerPreference { get; set; }
    }
    public class UserSettingConfig
    {
        public string TableNameUserPreference { get; set; }
        public string TableNameGlobalPreference { get; set; }
        public string TableNameCustomerPreference { get; set; }

        public static UserSettingConfig Load(IConfiguration config)
        {
            UserSettingConfig result = null;
            try
            {
                IConfigurationSection section = config.GetSection("UserSettingConfig");
                // section.Get requires Microsoft.Extensions.Hosting
                result = section?.Get<UserSettingConfig>();
            }
            catch (Exception ex)
            {
            }
            return result;
        }
    }
}