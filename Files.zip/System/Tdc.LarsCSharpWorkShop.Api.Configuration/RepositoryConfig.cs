using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Tdc.LarsCSharpWorkShop.Api.Configuration
{
    public interface IRepositoryConfig
    {
        List<RepositoryConfigSetting> RepositoryConfigSettings { get; set; }
    }
    public class RepositoryConfig : IRepositoryConfig
    {
        public List<RepositoryConfigSetting> RepositoryConfigSettings { get; set; }

        public static RepositoryConfig Load(IConfiguration config)
        {
            RepositoryConfig result = null;
            try
            {
                IConfigurationSection section = config.GetSection("RepositoryConfig");
                // section.Get requires Microsoft.Extensions.Hosting
                result = section?.Get<RepositoryConfig>();
            }
            catch (Exception ex)
            {
            }
            return result;
        }
    }

    public class RepositoryConfigSetting
    {
        public int BuildOrder { get; set; }
        public string Url { get; set; }
        public string RepositoryName { get; set; }
        public string PathWithoutRepositoryName { get; set; }
        public bool UseHttps { get; set; } = false;
        public string HttpPort { get; set; }
        public string HttpsPort { get; set; }
        public string Path => System.IO.Path.Combine(PathWithoutRepositoryName, RepositoryName);
        public string IISAppPort { get; set; }
        public string IISSslPort { get; set; }
        public string DockerImageName {
            get {
                return Regex.Replace(RepositoryName ?? String.Empty, @"crown\.insite\.[a-zA-Z]+\.", "").ToLower();
            }
            private set { }
        }
        public string RepositoryNameLowerCase {
            get {
                return RepositoryName.ToLower();
            }
            private set { }
        }
    }
}
