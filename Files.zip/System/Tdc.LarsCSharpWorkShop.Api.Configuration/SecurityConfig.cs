using Microsoft.Extensions.Configuration;
using System;
using Tdc.LarsCSharpWorkShop.Api.Common.Security.Authentication;

namespace Tdc.LarsCSharpWorkShop.Api.Configuration
{
    public interface ISecurityConfig : IConfig
    {
        public Authentication Authentication { get; set; }
    }
    public class SecurityConfig : ISecurityConfig
    {
        public Authentication Authentication { get; set; }

        public static SecurityConfig Load(IConfiguration config)
        {
            SecurityConfig result = null;
            try
            {
                IConfigurationSection section = config.GetSection("SecurityConfig");
                // section.Get requires Microsoft.Extensions.Hosting
                result = section?.Get<SecurityConfig>();
            }
            catch (Exception ex)
            {
            }
            return result;
        }
    }
}

