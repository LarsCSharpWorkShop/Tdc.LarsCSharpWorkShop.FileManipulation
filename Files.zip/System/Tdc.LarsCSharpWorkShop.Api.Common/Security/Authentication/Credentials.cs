using System.Text.Json.Serialization;

namespace Tdc.LarsCSharpWorkShop.Api.Common.Security.Authentication
{
    public class Credentials
    {
        [JsonPropertyName("client_id")]
        public string ClientId { get; set; }
        [JsonPropertyName("client_secret")]
        public string ClientSecret { get; set; }
        [JsonPropertyName("audience")]
        public string Audience { get; set; }
        [JsonPropertyName("grant_type")]
        public string GrantType { get; set; }
        [JsonPropertyName("emailAddress")]
        public string EmailAddress { get; set; }
        [JsonPropertyName("customerId")]
        public string CustomerId { get; set; }
        public Credentials() { }

    }
}