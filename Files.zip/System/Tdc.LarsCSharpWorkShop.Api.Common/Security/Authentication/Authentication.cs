namespace Tdc.LarsCSharpWorkShop.Api.Common.Security.Authentication
{
    public class Authentication
    {
        public Credentials Credentials { get; set; }
        public string JsonWebToken { get; set; }
    }
}