using System;
using System.IO;
using System.Runtime.Serialization;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Xml;
using System.Xml.Serialization;

namespace Tdc.LarsCSharpWorkShop.Api.Common
{
    public static class Serialization
    {
        public static string Serialize(object value)
        {
            if (value != null)
            {
                try
                {
                    JsonSerializerOptions options = new()
                    {                        
                        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingDefault,
                        WriteIndented = true
                    };
                    return JsonSerializer.Serialize(value, options);
                }
                catch (Exception ex)
                {
                    return "Unable to serialize the object. " + ex.Message;
                }
            }
            return $"The value is null and cannot be serialized.";
        }

        public static T Deserialize<T>(string value)
        {
            if (value != null)
            {
                try
                {
                    return JsonSerializer.Deserialize<T>(value);
                }
                catch
                {
                    return default;
                }              
            }
            return default;
        }

        private static string SerializeUsingDataContract(object value)
        {
            if (value != null)
            {
                DataContractSerializer serializer = new DataContractSerializer(value.GetType());
                StringWriter stringWriter = new StringWriter();
                using (XmlTextWriter writer = new XmlTextWriter(stringWriter))
                {
                    writer.Formatting = Formatting.Indented;
                    serializer.WriteObject(writer, value);
                    writer.Flush();
                    return stringWriter.ToString();
                }
            }
            return $"The value is null and cannot be serialized.";
        }

        private static T DeSerializeUsingDataContract<T>(string value)
        {
            DataContractSerializer serializer = new DataContractSerializer(typeof(T));
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(value);
            XmlDictionaryReader reader = XmlDictionaryReader.CreateTextReader(bytes, new XmlDictionaryReaderQuotas());
            return (T)serializer.ReadObject(reader);
        }

    }
}
