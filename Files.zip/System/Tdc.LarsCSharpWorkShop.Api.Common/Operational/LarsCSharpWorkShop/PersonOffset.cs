﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Tdc.LarsCSharpWorkShop.Api.Common
{
    public class PersonOffset
    {
        const int FIRST_NAME_LENGTH = 20;
        const int LAST_NAME_LENGTH = 20;
        static public int FileRecordSize = 40;

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Display => $"""{FirstName} {LastName}""";

        public PersonOffset(string s)
        {
            FirstName = s.Substring(0, FIRST_NAME_LENGTH);
            LastName = s.Substring(FIRST_NAME_LENGTH);                        
        }        
        public string FileRecord => $"{FirstName.PadRight(FIRST_NAME_LENGTH, ' ')}{LastName.PadRight(LAST_NAME_LENGTH, ' ')}";
    }
}
