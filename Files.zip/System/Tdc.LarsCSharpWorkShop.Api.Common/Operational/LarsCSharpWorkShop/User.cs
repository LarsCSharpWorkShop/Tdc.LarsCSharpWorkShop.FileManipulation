﻿using System;

namespace Tdc.LarsCSharpWorkShop.Api.Common.Operational.LarsCSharpWorkShop
{
    public partial class User : BaseCommon
    {
        public long? UserId { get; set; }      
        public string EmailAddress { get; set; }
        public string Password { get; set; }

        public User()
        {
        }
        public override bool RequiredFieldsExist()
        {
            return !string.IsNullOrWhiteSpace(EmailAddress);
        }
    }
}
