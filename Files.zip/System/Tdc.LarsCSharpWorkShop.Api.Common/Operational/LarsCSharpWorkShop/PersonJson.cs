﻿using System.Collections.Generic;
using System.Text.Json.Serialization;
using System.Xml.Serialization;

namespace Tdc.LarsCSharpWorkShop.Api.Common
{
    public class PersonJson
    {      
        public string FirstName { get; set; }        
        public string LastName { get; set; }
        [JsonIgnore(Condition = JsonIgnoreCondition.Always)]
        public Dictionary<int, string> Dictionary { get; set; } = new Dictionary<int, string>();
        [JsonIgnore(Condition = JsonIgnoreCondition.Always)]
        public string Display => $"""{FirstName} {LastName}""";
    }
}
