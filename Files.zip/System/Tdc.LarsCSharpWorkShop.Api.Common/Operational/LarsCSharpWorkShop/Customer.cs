﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tdc.LarsCSharpWorkShop.Api.Common.Operational.LarsCSharpWorkShop
{
    public class Customer : BaseCommon
    {
        public long? CustomerId { get; set; }
        public User User { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public override bool RequiredFieldsExist()
        {
            return !string.IsNullOrWhiteSpace(FirstName)
                   && !string.IsNullOrWhiteSpace(LastName);
        }

        public void ClearPii()
        {
            FirstName = "";
            LastName = "";
        }
    }
}
