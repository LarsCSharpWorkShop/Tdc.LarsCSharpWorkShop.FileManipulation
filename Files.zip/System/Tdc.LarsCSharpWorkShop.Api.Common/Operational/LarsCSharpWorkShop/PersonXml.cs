﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Tdc.LarsCSharpWorkShop.Api.Common
{

    [XmlRoot("Person")]
    public class PersonXml
    {
        [XmlElement("FirstName")]
        public string FirstName { get; set; }
        [XmlElement("LastName")]
        public string LastName { get; set; }
        [XmlIgnore]
        public Dictionary<int, string> Dictionary { get; set; } = new Dictionary<int, string>();
        [XmlElement("Display")]
        public string Display => $"""{FirstName} {LastName}""";
    }
}
