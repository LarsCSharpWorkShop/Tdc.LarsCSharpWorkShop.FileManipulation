﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tdc.LarsCSharpWorkShop.Api.Common.Operational.LarsCSharpWorkShop
{
    public class Product : BaseCommon
    {
        public long? ProductId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }

        public override bool RequiredFieldsExist()
        {
            return !string.IsNullOrWhiteSpace(Name) &&
                !string.IsNullOrWhiteSpace(Description) &&
                Price >= 0.0;
        }
    }
}
