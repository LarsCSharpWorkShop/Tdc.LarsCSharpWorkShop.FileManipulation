﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Tdc.LarsCSharpWorkShop.Api.Common
{
    public class PersonCsv
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public Dictionary<int, string> Dictionary { get; set; } = new Dictionary<int, string>();

        public string Display => $"""{FirstName} {LastName}""";
    }
}
