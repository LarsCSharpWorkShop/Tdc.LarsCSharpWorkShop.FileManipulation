using System;
using Tdc.LarsCSharpWorkShop.Api.Common;

namespace Tdc.LarsCSharpWorkShop.Api.Common
{
    public abstract class BaseCommon
    {
        public abstract bool RequiredFieldsExist();

        public int? Sequence { get; set; }
        public DateTime? CreateDateTime { get; set; }
        public long? CreateUserId { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public long? UpdateUserId { get; set; }
        public DateTime? DeleteDateTime { get; set; }
        public long? DeleteUserId { get; set; }        

        public BaseCommon()
        {           
        }
    }
}