﻿/* File Methods
 * Used Most 
 * ----------
 * Exists
 * Delete 
 * Copy
 * Move
  
 * ReadLines  
 * ReadAllLines 
 * WriteAllLines
 * AppendAllLines
 * 
 * ReadAllBytes
 * WriteAllBytes
 * 
 * ReadAllText
 * WriteAllText
 * AppendText
 * AppendAllText
 *   
 * Used Less
 * ---------
 * Open
 * Create
 * Replace 
 * OpenRead
 * OpenWrite 
 * SetAttributes
 * SetCreationTime
 * SetCreationTimeUtc
 * SetLastAccessTime
 * SetLastAccessTimeUtc
 * SetLastWriteTime
 * SetLastWriteTimeUtc
 * GetAttributes
 * GetCreationTime
 * GetCreationTimeUtc
 * GetLastAccessTime
 * GetLastAccessTimeUtc
 * GetLastWriteTime
 * GetLastWriteTimeUtc  
 *   
 * Used Least
 * ----------
 * AppendAllBytes
 * CreateSymbolicLink
 * CreateText
 * Decrypt
 * Encrypt 
 * OpenHandle
 * OpenText
 * ResolveLinkTarget
 * SetUnixFileMode 
 * GetUnixFileMode
 * 
 * Same as above but for Async
 * ---------------------------
 * AppendAllBytesAsync
 * AppendAllLinesAsync
 * AppendAllTextAsync
 * ReadAllBytesAsync 
 * ReadAllLinesAsync
 * ReadAllTextAsync
 * ReadLinesAsync
 * WriteAllBytesAsync 
 * WriteAllLinesAsync 
 * WriteAllTextAsync
 */
/* Directory Methods
 * Used Most
 * ---------
 * CreateDirectory
 * Delete
 * Exists
 * GetFiles
 * GetDirectories
 * Move 
 * GetCurrentDirectory            
 * GetDirectoryRoot
 *
 * Used Less
 * ---------
 * GetCreationTime
 * GetCreationTimeUtc
 * GetFileSystemEntries
 * GetLastAccessTime
 * GetLastAccessTimeUtc
 * GetLastWriteTime
 * GetLastWriteTimeUtc    
 * SetCreationTime 
 * SetCreationTimeUtc
 * SetCurrentDirectory
 * SetLastAccessTime
 * SetLastAccessTimeUtc
 * SetLastWriteTime
 * SetLastWriteTimeUtc
 *
 * Used Least
 * ----------
 * CreateSymbolicLink
 * CreateTempSubdirectory
 * EnumerateDirectories
 * EnumerateFiles
 * EnumerateFileSystemEntries
 * GetLogicalDrives
 * GetParent
 */
/* Path
 * Used Most
 * ---------
 * Combine
 * Exists
 * GetFullPath
 * GetFileName 
 * GetFileNameWithoutExtension 
 * GetPathRoot
 * 
 * Used Less
 * ---------
 * DirectorySeparatorChar
 * VolumeSeparatorChar
 * PathSeparator
 * AltDirectorySeparatorChar    
 * EndsInDirectorySeparator
 * InvalidPathChars
 * GetInvalidFileNameChars
 * GetInvalidPathChars 
 * 
 * Used Least
 * ---------
 * Join
 * TryJoin 
 * ChangeExtension          
 * GetRandomFileName
 * GetRelativePath
 * GetTempFileName
 * GetTempPath
 * HasExtension
 * IsPathFullyQualified
 * IsPathRooted      
 */

/* FileInfo
 * Used Most
 * ---------
 * CopyTo
 * Create
 * Delete
 * Directory
 * DirectoryName
 * Exists
 * Extension
 * FullName
 * Length
 * MoveTo
 * Name
 *
 * Used Less
 * ---------
 * CreationTime
 * CreationTimeUtc
 * LastAccessTime
 * LastAccessTimeUtc
 * LastWriteTime
 * LastWriteTimeUtc       
 * Open
 * OpenRead
 * OpenText
 * OpenWrite           
 * CreateText
 * AppendText
 * Attributes
 *     
 * Used Least
 * ----------
 * CreateAsSymbolicLink       
 * Decrypt       
 * Encrypt       
 * GetAccessControl
 * IsReadOnly      
 * Refresh
 * Replace          
 * Serialize
 * SetAccessControl
 * ToString
 */
/* DirectoryInfo
 * Used Most
 * --------- 
 * Attributes
 * Create
 * CreateSubdirectory
 * Delete
 * Exists
 * Extension
 * FullName 
 * GetDirectories
 * GetFiles
 * MoveTo
 * Name
 * Root
 * SetAccessControl 
 * 
 * Used Less
 * --------- 
 * CreationTime
 * CreationTimeUtc
 * LastAccessTime
 * LastAccessTimeUtc
 * LastWriteTime
 * LastWriteTimeUtc  
 * Refresh
 * 
 * Used Least
 * ----------
 * CreateAsSymbolicLink
 * EnumerateDirectories            
 * GetFileSystemInfos
 * Serialize
 * ToString
 */
/* DriveInfo 
 * Used Most
 * ---------
 * TotalSize
 * TotalFreeSpace
 * AvailableFreeSpace
 * VolumeLabel
 * DriveFormat
 * DriveType
 * IsReady
 * Name
 * RootDirectory
 * 
 * Used Least
 * ---------
 * Serialize

   FileSystemWatcher
*/