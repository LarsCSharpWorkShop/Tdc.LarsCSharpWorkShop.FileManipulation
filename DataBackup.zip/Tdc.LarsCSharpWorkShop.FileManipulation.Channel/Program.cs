﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Tdc.LarsCSharpWorkShop.FileManipulation.Channel;

HostApplicationBuilder builder = Host.CreateApplicationBuilder(args);
builder.Services.AddHostedService<Worker>();

using IHost host = builder.Build();
host.Run();
