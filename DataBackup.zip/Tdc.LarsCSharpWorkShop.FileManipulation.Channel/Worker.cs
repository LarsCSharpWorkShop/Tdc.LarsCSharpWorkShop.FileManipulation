﻿using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

namespace Tdc.LarsCSharpWorkShop.FileManipulation.Channel
{
    public class Worker : BackgroundService
    {
        private readonly IHostApplicationLifetime iHostApplicationLifetime;
        public Worker(IHostApplicationLifetime iHostApplicationLifetime)
        {
            this.iHostApplicationLifetime = iHostApplicationLifetime;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            try
            {
                string path = Path.Combine("D:", "YouTube", "Lars C# Workshop", "Code", "DeepDive", "07 File Manipulation", "Data");
                Console.WriteLine(path);
                Directory.SetCurrentDirectory(path);

                string sourcePath1 = Path.Combine(path, "TextFile1.txt");
                string sourcePath2 = Path.Combine(path, "TextFile2.txt");

                string s = File.ReadAllText(sourcePath1);
                File.WriteAllText(sourcePath1, s);
                
                List<string> lines = File.ReadLines(sourcePath2).ToList();
                File.WriteAllLines(sourcePath2, lines);                                
            }
            catch
            {
                throw;
            }
            finally
            {
                this.iHostApplicationLifetime.StopApplication();
            }
        }

        private void Copy(string source, string destination)
        {
            DirectoryInfo diSource = new DirectoryInfo(source);
            DirectoryInfo diDestination = new DirectoryInfo(destination);
            diDestination.Create();

            CopyAll(diSource, diDestination);
        }

        private void CopyAll(DirectoryInfo source, DirectoryInfo destination)
        {
            foreach (FileInfo fi in source.GetFiles())
            {
                fi.CopyTo(Path.Combine(destination.FullName, fi.Name), true);
            }
            foreach (DirectoryInfo diSubDir in source.GetDirectories())
            {
                DirectoryInfo destinationSubDir = destination.CreateSubdirectory(diSubDir.Name);
                CopyAll(diSubDir, destinationSubDir);
            }
        }
    }
}
